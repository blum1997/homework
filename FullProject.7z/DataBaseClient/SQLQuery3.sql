﻿Select
*
from Users