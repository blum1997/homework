﻿SELECT
*
FROM Users